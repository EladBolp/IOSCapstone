//
//  Dish+CoreDataClass.swift
//  LittleLemonMenu
//
//  Created by Manuchimso Oliver on 05/02/2023.
//
//

import Foundation
import CoreData

@objc(Dish)
public class Dish: NSManagedObject {

}
