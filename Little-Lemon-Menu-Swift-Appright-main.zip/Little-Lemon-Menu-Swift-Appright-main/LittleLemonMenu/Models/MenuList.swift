//
//  MenuList.swift
//  LittleLemonMenu
//
//  Created by Manuchimso Oliver on 05/02/2023.
//

import Foundation

struct MenuList: Decodable {
    let menu: [MenuItem]
}
